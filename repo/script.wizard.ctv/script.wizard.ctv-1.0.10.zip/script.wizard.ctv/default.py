# Config Wizard

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc, xbmcaddon, os, sys
import downloader
import extract
import time
import shutil
from resources.modules import main
addon_id = 'script.wizard.ctv'
try: 		from t0mm0.common.addon import Addon
except: from t0mm0_common_addon import Addon
addon = main.addon
try: 		from t0mm0.common.net import Net
except: from t0mm0_common_net import Net
net = Net()
settings = xbmcaddon.Addon(id=addon_id)
net.set_user_agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'); 

#==========================Help WIZARD=====================================================================================================
def HELPCATEGORIES():
    addon.show_small_popup(title='Config Wizard', msg='Please Wait, Loading Options...', delay=5000, image='')
    if ((XBMCversion['Ver'] in ['','']) or (int(XBMCversion['two']) < 12)) and (settings.getSetting('bypass-xbmcversion')=='false'):
        eod(); 
        addon.show_ok_dialog(["Compatibility Issue: Outdated CosmiTV Setup","Please upgrade to a newer version of CosmiTV first!","Contact your sales rep for Support!"], title="CosmiTV "+XBMCversion['Ver'], is_error=False); 
        DoA('Back'); 
    else:
        link=OPEN_URL('http://www.googledrive.com/host/0B6rP0uH2SjTsZS1mVmhBa01HS1k/update/links.txt').replace('\n','').replace('\r','')
        match=re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)".+?ype="(.+?)"').findall(link)
        import platform
        xinfo = str(platform.uname())
        
        
        profiledir = xbmc.translatePath(settings.getAddonInfo('profile')).decode('utf-8')
        #main.addHELPDir(profiledir,'','upgradewiz','','',xinfo,'')
        #main.addHELPDir(xinfo,'','helpwizard','','',xinfo,'')
        
        
        for name,url,iconimage,fanart,description,filetype in match:
            
            

            if int(XBMCversion['two']) == 13 and 'CTV2' in name:
                main.addHELPDir(name+" "+XBMCversion['two'],url,'helpwizard',iconimage,fanart,description,filetype)
                main.AUTO_VIEW('movies')
            elif int(XBMCversion['two']) == 12 and 'CTV1' in name:
                main.addHELPDir(name+" "+XBMCversion['two'],url,'helpwizard',iconimage,fanart,description,filetype)
                main.AUTO_VIEW('movies')               
            elif int(XBMCversion['two']) >= 16 and 'CTVx2' in name:
                main.addHELPDir(name+" "+XBMCversion['two'],url,'helpwizard',iconimage,fanart,description,filetype)
            elif int(XBMCversion['two']) >= 13 and 'Upgrade' in name:
                main.addHELPDir(name,url,'upgradewiz',iconimage,fanart,description,filetype)
                main.AUTO_VIEW('movies')  

            
            #if 'status' in filetype:
                #main.addHELPDir(name,url,'wizardstatus',iconimage,fanart,description,filetype)
            #else:    
                #main.addHELPDir(name,url,'helpwizard',iconimage,fanart,description,filetype)
                #main.AUTO_VIEW('movies')
                #print [name,url]
        #main.addHELPDir('Testing','http://www.firedrive.com/file/################','helpwizard',iconimage,fanart,description,filetype) ## For Testing to test a url with a FileHost.
        ## ### ## \/ OS Check and Button Suggestions \/ ## ### ## 
        #if   sOS.lower() in ['win32']: SuggestButton('Windows')    ## Windows.
        #elif sOS.lower() in ['linux']: SuggestButton('Linux')     ## May include android stuff as well.
        #elif sOS.lower() in ['mac','osx']: SuggestButton('MAC')   ## 
        #elif sOS.lower() in ['android']: SuggestButton('Android') ## 
        ## ### ## 

def SuggestButton(msg):
	addon.show_ok_dialog(["By the looks of your operating system","we suggest clicking: ",""+msg], title="OS: "+sOS, is_error=False); 

def OPEN_URL(url): req=urllib2.Request(url); req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'); response=urllib2.urlopen(req); link=response.read(); response.close(); return link



def UPGRADEWIZ(name,url,description,filetype):
    path=xbmc.translatePath(os.path.join('special://home/addons','packages')).decode('utf-8')
    sdcard_dl=xbmc.translatePath(os.path.join("/mnt/internal_sd","Download")).decode('utf-8')
    confirm=xbmcgui.Dialog()
    if confirm.yesno("CosmiTV","Would you like CosmiTV to ","Upgrade now? "," "):    
        dp=xbmcgui.DialogProgress(); dp.create("CosmiTV","Downloading ",'','Please Wait')
        lib=os.path.join(path,name+'.zip')
        try: os.remove(lib)
        except: pass
        if '[error]' in url: print url; dialog=xbmcgui.Dialog(); dialog.ok("Error!",url); return
        else: print url
        
        #profiledir = xbmc.translatePath(settings.getAddonInfo('profile')).decode('utf-8')
        #dialog=xbmcgui.Dialog(); dialog.ok("THIS!",profiledir); return
        ### ## File Host Handling ## /\
        if not os.path.isdir(sdcard_dl):
            os.makedirs(sdcard_dl)
            
        downloader.download(url,lib,dp)
        #->addonfolder=xbmc.translatePath(os.path.join('special://','home'))
        
        time.sleep(2)
        dp.update(0,"","Extracting Zip Please Wait")
        #->print '======================================='; print addonfolder; print '======================================='
        extract.all(lib,sdcard_dl,dp)
        time.sleep(2)
        dp.create("CosmiTV","Installing Version...","System will Reboot when completed","Please Wait...")
        cmdinstall = 'su -c pm install /mnt/internal_sd/Download/cosmitvx2.apk'
        cmduninstall = 'pm uninstall com.example.helloandroid'
        #s = subprocess.call(cmdinstall)
        os.system(cmdinstall.encode('utf-8'))
        xbmc.Reset()
        #XBMC.Reboot()
        
def HELPWIZARD(name,url,description,filetype):
    path=xbmc.translatePath(os.path.join('special://home/addons','packages'))
    confirm=xbmcgui.Dialog()
    if confirm.yesno("CosmiTV","Would you like CosmiTV to ","customize your add-on selection? "," "):
        dp=xbmcgui.DialogProgress(); dp.create("CosmiTV","Downloading ",'','Please Wait')
        lib=os.path.join(path,name+'.zip')
        try: os.remove(lib)
        except: pass
        #url=SockShare(url)
        if '[error]' in url: print url; dialog=xbmcgui.Dialog(); dialog.ok("Error!",url); return
        else: print url
        ### ## File Host Handling ## /\
        downloader.download(url,lib,dp)
        #return ## For Testing 2 Black Overwrite of stuff. ##
    #if filetype == 'addon':
        #addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
    #elif filetype == 'media':
        #addonfolder = xbmc.translatePath(os.path.join('special://','home'))    
#attempt Shortcuts
    #elif filetype == 'main':
        addonfolder=xbmc.translatePath(os.path.join('special://','home'))
        # addonfolder=xbmc.translatePath(os.path.join('special://','home', 'addons'))
        time.sleep(2)
        dp.update(0,"","Extracting Zip Please Wait")
        #print '======================================='; print addonfolder; print '======================================='
        extract.all(lib,addonfolder,dp)
        skin =  xbmc.getSkinDir()
        if xbmc.getCondVisibility("System.HasAddon(skin.cosmitv.ctv)") and (skin == "skin.cosmitv.ctv"):
            skinsshortcutsfile = 'http://www.googledrive.com/host/0B6rP0uH2SjTsZS1mVmhBa01HS1k/update/skin.cosmitv.ctv.shortcuts.txt'
        elif xbmc.getCondVisibility("System.HasAddon(skin.cosmitv-x2.ctv)") and (skin == "skin.cosmitv-x2.ctv"):
            skinsshortcutsfile = 'http://www.googledrive.com/host/0B6rP0uH2SjTsZS1mVmhBa01HS1k/update/skin.cosmitv-x2.ctv.shortcuts.txt'
        else:
            return
        link=OPEN_URL(skinsshortcutsfile)
        proname=xbmc.getInfoLabel("System.ProfileName")
        shorts=re.compile('shortcut="(.+?)"').findall(link)
        for shortname in shorts: xbmc.executebuiltin("Skin.SetString(%s)" % shortname)
        #xbmc.executebuiltin('Skin.SetString(CustomBackgroundPath,%s)' %img)
        #xbmc.executebuiltin('Skin.SetBool(ShowBackgroundVideo)')       ## Set to true so we can later set them to false.
        #xbmc.executebuiltin('Skin.SetBool(ShowBackgroundVis)')         ## Set to true so we can later set them to false.
        #xbmc.executebuiltin('Skin.SetBool(HideBackGroundFanart)')      ## Set to true.
        #xbmc.executebuiltin('Skin.SetBool(HideVisualizationFanart)')   ## Set to true.
        #xbmc.executebuiltin('Skin.SetBool(AutoScroll)')                ## Set to true.
        #xbmc.executebuiltin('Skin.ToggleSetting(ShowBackgroundVideo)') ## Switching from true to false.
        #xbmc.executebuiltin('Skin.ToggleSetting(ShowBackgroundVis)')   ## Switching from true to false.
        #xbmc.executebuiltin('Skin.SetString(CustomBackgroundPath,%s)' % (os.path.join('special://','home','media','SKINDEFAULT.png')))
        #xbmc.executebuiltin('Skin.SetBool(UseCustomBackground)')
        # xbmc.executebuiltin('Skin.Reset(UseCustomBackground)')
        
        time.sleep(2)
        xbmc.executebuiltin('UnloadSkin()'); xbmc.executebuiltin('ReloadSkin()'); xbmc.executebuiltin("LoadProfile(%s)" % proname)
        time.sleep(1)
        dialog=xbmcgui.Dialog(); dialog.ok("Success!","Installation Complete", "[COLOR red]Brought To You By CosmiTV[/COLOR]")
        deleteold(lib,'file')
        ##

def WIZARDSTATUS(url):
    link=OPEN_URL(url).replace('\n','').replace('\r','')
    match=re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)".+?ype="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description,filetype in match: header="[B][COLOR gold]"+name+"[/B][/COLOR]"; msg=(description); TextBoxes(header,msg)

def TextBoxes(heading,anounce):
        class TextBox():
            WINDOW=10147; CONTROL_LABEL=1; CONTROL_TEXTBOX=5
            def __init__(self,*args,**kwargs):
                xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
                self.win=xbmcgui.Window(self.WINDOW) # get window
                xbmc.sleep(500) # give window time to initialize
                self.setControls()
            def setControls(self):
                self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
                try: f=open(anounce); text=f.read()
                except: text=anounce
                self.win.getControl( self.CONTROL_TEXTBOX ).setText (str(text))
                return
        TextBox()
#==========
def DoA(a): xbmc.executebuiltin("Action(%s)" % a) #DoA('Back'); # to move to previous screen.
def eod(): addon.end_of_directory()



def deleteold(name,type): 
    if 'folder' in type:
	    addonfolder = xbmc.translatePath(os.path.join('special://home/addons', ''))
	    path=os.path.join(addonfolder, name)
	    for root, dirs, files in os.walk(path):
	       for f in files:
	            os.unlink(os.path.join(root, f))
	       for d in dirs:
	            shutil.rmtree(os.path.join(root, d))
	    try:
	        os.rmdir(path)
	    except:
	        pass
    else:
	    file = xbmc.translatePath(os.path.join(name))
	    try:
	        os.remove(file)
	    except:
	        pass



#==========OS Type & XBMC Version===========================================================================================
def get_xbmc_os():
	try: xbmc_os = str(os.environ.get('OS'))
	except:
		try: xbmc_os = str(sys.platform)
		except: xbmc_os = "unknown"
	return xbmc_os
XBMCversion={}; XBMCversion['All']=xbmc.getInfoLabel("System.BuildVersion"); XBMCversion['Ver']=XBMCversion['All']; XBMCversion['Release']=''; XBMCversion['Date']=''; 
if ('Git:' in XBMCversion['All']) and ('-' in XBMCversion['All']): XBMCversion['Date']=XBMCversion['All'].split('Git:')[1].split('-')[0]
if ' ' in XBMCversion['Ver']: XBMCversion['Ver']=XBMCversion['Ver'].split(' ')[0]
if '-' in XBMCversion['Ver']: XBMCversion['Release']=XBMCversion['Ver'].split('-')[1]; XBMCversion['Ver']=XBMCversion['Ver'].split('-')[0]
if len(XBMCversion['Ver']) > 1: XBMCversion['two']=str(XBMCversion['Ver'][0])+str(XBMCversion['Ver'][1])
else: XBMCversion['two']='00'
if len(XBMCversion['Ver']) > 3: XBMCversion['three']=str(XBMCversion['Ver'][0])+str(XBMCversion['Ver'][1])+str(XBMCversion['Ver'][3])
else: XBMCversion['three']='000'
sOS=str(get_xbmc_os()); 
print [['Version All',XBMCversion['All']],['Version Number',XBMCversion['Ver']],['Version Release Name',XBMCversion['Release']],['Version Date',XBMCversion['Date']],['OS',sOS]]
#==========END HELP WIZARD==================================================================================================
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]; cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&'); param={}
                for i in range(len(pairsofparams)):
                        splitparams={}; splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
        return param

params=get_params(); url=None; name=None; mode=None; year=None; imdb_id=None

try:    fanart=urllib.unquote_plus(params["fanart"])
except: pass
try:    description=urllib.unquote_plus(params["description"])
except: pass
try:    filetype=urllib.unquote_plus(params["filetype"])
except: pass
try:		url=urllib.unquote_plus(params["url"])
except: pass
try:		name=urllib.unquote_plus(params["name"])
except: pass
try:		mode=urllib.unquote_plus(params["mode"])
except: pass
try:		year=urllib.unquote_plus(params["year"])
except: pass
print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name); print "Year: "+str(year)

if mode==None or url==None or len(url)<1: HELPCATEGORIES()
elif mode=="wizardstatus": print""+url; items = WIZARDSTATUS(url)
elif mode=='helpwizard': HELPWIZARD(name,url,description,filetype)
elif mode=='upgradewiz': UPGRADEWIZ(name,url,description,filetype)
xbmcplugin.endOfDirectory(int(sys.argv[1]))        
