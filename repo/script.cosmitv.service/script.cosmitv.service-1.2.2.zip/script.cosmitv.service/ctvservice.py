import urllib,urllib2,sys,platform,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,struct,datetime,xbmcvfs
import extract
import downloader
import datetime
import time


addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')

url_mininstaller="https://googledrive.com/host/0B6rP0uH2SjTsMGttbVZ1LVhrM0k/dl/mininstaller.zip"


base_url = 'https://www.google.com'
debug = 'true'
dialog = xbmcgui.Dialog()

def addon_log(string):
    if debug == 'true':
        xbmc.log("[%s-%s]: %s" %(addon_id, addon_version, string), level=xbmc.LOGNOTICE)


class getUrl(object):
    def __init__(self, url, close=True, proxy=None, post=None, mobile=False, referer=None, cookie=None, output='', timeout='10'):
        if not proxy is None:
            proxy_handler = urllib2.ProxyHandler({'http':'%s' % (proxy)})
            opener = urllib2.build_opener(proxy_handler, urllib2.HTTPHandler)
            opener = urllib2.install_opener(opener)
        if output == 'cookie' or not close == True:
            import cookielib
            cookie_handler = urllib2.HTTPCookieProcessor(cookielib.LWPCookieJar())
            opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
            opener = urllib2.install_opener(opener)
        if not post is None:
            request = urllib2.Request(url, post)
        else:
            request = urllib2.Request(url,None)
        if mobile == True:
            request.add_header('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')
        else:
            request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0')
        if not referer is None:
            request.add_header('Referer', referer)
        if not cookie is None:
            request.add_header('cookie', cookie)
        response = urllib2.urlopen(request, timeout=int(timeout))
        if output == 'cookie':
            result = str(response.headers.get('Set-Cookie'))
        elif output == 'geturl':
            result = response.geturl()
        else:
            result = response.read()
        if close == True:
            response.close()
        self.result = result        
        
def make_request(url):

    if xbmc.abortRequested == True: sys.exit()
    addon_log('Request URL: %s' %url)
    headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0',
               'Referer' : base_url}
    try:
        req = urllib2.Request(url, None, headers)
        response = urllib2.urlopen(req)
        data = response.read()
        response.close()
        return data
    except urllib2.URLError, e:
        addon_log('We failed to open "%s".' %url)
        if hasattr(e, 'reason'):
            addon_log('We failed to reach a server.')
            addon_log('Reason: %s' %e.reason)
        if hasattr(e, 'code'):
            addon_log('We failed with error code - %s.' %e.code)            
            
############################################################        DELETE OLD PACKAGES          ###############################################################    
          
def DeletePackages():

    #print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))


    addon_log("finding packages")  
    for root, dirs, files in os.walk(packages_cache_path):
        file_count = 0
        file_count += len(files)
            
    addon_log("found " + str(file_count) + " packages")
    readytodelete1 = False
    readytodelete = False
    fcount=0  
    # Count files and give option to delete
    if file_count > 0:
        for f in files:
            t1 = datetime.datetime.utcfromtimestamp(os.path.getmtime(root+f))
            t2 = datetime.datetime.utcnow()
            addon_log("Package " + root+f + " is " + str(abs(t2 - t1)) + " hours old")
            readytodelete1 = abs(t2 - t1) > datetime.timedelta(hours=140)
            if readytodelete1 is True:
                fcount += 1

            
    # Count files and give option to delete
    if fcount > 0:
        #dialog = xbmcgui.Dialog()
        #if dialog.yesno("CosmiTV Clean up tool", "Found " + str(fcount) + " old addon files out of " + str(file_count) + " These files just take space", "Do you want to delete them now to clear space?"):
         fcount=0        
         for f in files:
             t1 = datetime.datetime.utcfromtimestamp(os.path.getmtime(root+f))
             t2 = datetime.datetime.utcnow()
             readytodelete = abs(t2 - t1) > datetime.timedelta(hours=140)
             if readytodelete is True:
                 addon_log('Deleting FILE: ==>' + root+f)
                 fcount += 1
                 os.unlink(os.path.join(root, f))
                 
            #dialog = xbmcgui.Dialog()
            #dialog.ok("CosmiTV", "      Deleted " + str(fcount) + " files. All Done!", "")


  

############################################################        DELETING CRASH LOGS          ###############################################################    
        
def DeleteCrashLogs():  
    print '############################################################       DELETING CRASH LOGS             ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Delete Old Crash Logs", '', "Do you want to delete them?"):
        path=loglocation()
        import glob
        for infile in glob.glob(os.path.join(path, 'xbmc_crashlog*.*')):
             File=infile
             print infile
             os.remove(infile)
    dialog = xbmcgui.Dialog()
    dialog.ok("CosmiTV", "Please Reboot To Take Effect !!", "")


def deleteold(name,type): 
    if 'folder' in type:
	    addonfolder = xbmc.translatePath(os.path.join('special://home/addons', ''))
	    path=os.path.join(addonfolder, name)
	    for root, dirs, files in os.walk(path):
	       for f in files:
	            os.unlink(os.path.join(root, f))
	       for d in dirs:
	            shutil.rmtree(os.path.join(root, d))
	    try:
	        os.rmdir(path)
	    except:
	        pass
    else:
	    file = xbmc.translatePath(os.path.join(name))
	    try:
	        os.remove(file)
	    except:
	        pass    
    

def INSTALL_MINIST(url):
    dialog = xbmcgui.Dialog()
    dp = xbmcgui.DialogProgress()
    dp.create("DEVICE SETUP","Downloading file ",'', 'Please Wait')
    import time
    path         =  xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib          =  os.path.join(path, 'ctv_mininst_file.zip')
    addonfolder  =  xbmc.translatePath(os.path.join('special://home/addons',''))
    dp.update(0,"Downloading... ",'', 'Please Wait')
    downloader.download(url, lib, dp)
    time.sleep(4)
    #dp.update(0, "Extracting file ",'To: ' + addonfolder,"Please Wait")
    dp.update(0, "Extracting file ","","Please Wait...")
    extract.all(lib,addonfolder,dp)
    time.sleep(2)
    xbmc.executebuiltin( "XBMC.ReloadSkin()" )
    time.sleep(2)
    #call update addons to refresh everything
    xbmc.executebuiltin('UpdateLocalAddons') 
    dialog.ok("DEVICE SETUP", "Step 1 Completed","Continue", "") 
    #xbmc.executebuiltin("XBMC.Container.Update(addons://script.mininstaller.ctv?mode=0,replace)")
    xbmc.executebuiltin("RunAddon(script.mininstaller.ctv)")
    #runScript('script.mininstaller.ctv')
    
def runScript(url):
    xbmc.executebuiltin('XBMC.RunPlugin(plugin://' + url +')')

    
    
def checkinet():
    if xbmc.abortRequested == True: sys.exit()	
    dialog = xbmcgui.Dialog()
    
    inetconnected=isconnected()
 
    if inetconnected:
        addon_log('Internet Connected')
        DeletePackages()
        confirm=xbmcgui.Dialog()
        if missingdeps():    
            if confirm.yesno("DEVICE SETUP","Your device is not configured yet!","configure device now?"):
                INSTALL_MINIST(url_mininstaller)
                
        if isskinbroken():
            backupgui = xbmc.translatePath(os.path.join('special://userdata', 'guisettings.xml.bak'))
            if os.path.isfile(backupgui):
                try:
                    z = open(backupgui, 'r')
                    a = z.read()
                    fixgui(a)
                except Exception, e:   
                    print "2nd EXCEPT FOR THIS : "  + str(e)
                    pass                    
            else:
                try:
                    skin =  xbmc.getSkinDir()
                    if skin == "skin.cosmitv-X2.ctv":
                        url_basegui="https://googledrive.com/host/0B6rP0uH2SjTsMGttbVZ1LVhrM0k/dl/basegui-x2.xml"
                    else:
                        url_basegui="https://googledrive.com/host/0B6rP0uH2SjTsMGttbVZ1LVhrM0k/dl/basegui.xml"         
                        
                    response = getUrl(url=url_basegui.strip()).result
                    fixgui(response)
                    restoregui = xbmc.translatePath(os.path.join('special://userdata', 'guisettings.xml'))
                    backupgui = xbmc.translatePath(os.path.join('special://userdata', 'guisettings.xml.bak'))
                    shutil.copyfile(restoregui, backupgui)                      
                except Exception, e:   
                    print "3nd EXCEPT FOR THIS : " + str(e)
                    pass                
         
    else:
        addon_log('No Internet Access')
        skin         =  xbmc.getSkinDir()
        if skin != "skin.cosmitv.ctv":
            dialog.ok("DEVICE SETUP", "You are not connected to Internet!", "Please plug the device to your internet router", "or press the [B][COLOR blue]BLUE[/B][/COLOR] button on your remote and select WIFI Settings")
        else:
            dialog.ok("DEVICE SETUP", "You are not connected to Internet!", "Please connect the device to your internet router now then press [B][COLOR blue]OK[/B][/COLOR]", "or press [B][COLOR blue]OK[/B][/COLOR] and select WIFI Settings")
            if not isconnected():
                opensettings()
        
        dialog.ok("DEVICE SETUP", "Press OK", "to continue setup")
        checkinet()


def fixgui(a):
    addon_log('fixgui')
    skin         =  xbmc.getSkinDir()
    r='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'% skin
            
    match=re.compile(r).findall(a)
    print match
    for type,string,setting in match:
        setting=setting.replace('&quot;','') .replace('&amp;','&') 
        xbmc.executebuiltin("Skin.Set%s(%s,%s)"%(type.title(),string,setting)) 

    time.sleep(1)
    xbmc.executebuiltin('UnloadSkin()') 
    xbmc.executebuiltin('ReloadSkin()')    
    time.sleep(1)   
  
        
def opensettings():
	packagepath = os.popen('pm path com.rk.setting').read()
	if packagepath:
		xbmc.executebuiltin('StartAndroidActivity("com.rk.setting")')
	else:
		xbmc.executebuiltin('StartAndroidActivity("com.android.settings")')

        
        
def isconnected():
    inetconnected = False  
    try:
        response=urllib2.urlopen('https://www.google.com',timeout=10)
        inetconnected =True
    except urllib2.URLError:
        inetconnected = False  
        
    return inetconnected


def waitForConnection2():
        while(not isconnected()):
            if xbmc.abortRequested == True:
                break
            xbmc.sleep(1000)
        return True
    


    
def waitForConnection():
        sleeptime = 0

        while sleeptime < 6000:
            xbmc.sleep(500)

            if isconnected():
                    break
            sleeptime += 100
        else:
            return False

        return True        
        

        
def isskinbroken():
    addon_log('isskinbroken')
    skin         =  xbmc.getSkinDir()
    if skin != "skin.cosmitv.ctv" or skin != "skin.cosmitv-x2.ctv":
        addon_log(skin +' : skin is not ctv skin so do nothing')
        return False
        
    guisettings = xbmc.translatePath(os.path.join('special://userdata', 'guisettings.xml'))

    z = open(guisettings, 'r')
    a = z.read()
    r='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'% skin
            
    match=re.compile(r).findall(a)
    #print match
    fnd=0
    for type,string,setting in match:
        setting=setting.replace('&quot;','') .replace('&amp;','&') 
        if string.startswith('CustomMovies') and len(setting) > 1:
            fnd=fnd+1

            
    if fnd > 0:
        addon_log('skin is not broken')
        return False
    else:
        addon_log('skin is broken')
        return True
        
def missingdeps():
    addon_log('missingdeps')
    skin         =  xbmc.getSkinDir()
    if skin != "skin.cosmitv.ctv":
        addon_log(skin +' : skin is not ctv skin so do nothing')
        return False
        
    if not xbmc.getCondVisibility('System.HasAddon(script.worldtv.ctv)'):    
       return True
    else:
        return False  
    '''
    dependencies = ['script.worldtv.ctv']
    missingcntr = 0
    for scripts in dependencies:
        needaddon=xbmc.translatePath(os.path.join('special://home/addons',scripts))
        if os.path.exists(needaddon)==False:
		     missingcntr += 1        
    #if xbmc.abortRequested == True: sys.exit()
    
    if missingcntr > 0:
       return True
    else:
        return False    
    ''' 
    
def checkdeps_old():
    dependencies = ['script.worldtv.ctv','skin.cosmitv.ctv']
    missingcntr = 0
    for scripts in dependencies:
        needaddon=xbmc.translatePath(os.path.join('special://home/addons',scripts))
        if os.path.exists(needaddon)==False:
		     missingcntr += 1
             
    if xbmc.abortRequested == True: sys.exit()
    if missingcntr > 0:
         dialog = xbmcgui.Dialog()
         dialog.ok("CosmiTV", "It seems that you are missing some required files", "The Window will now change to Backup/Restore settings", "Select RESTORE and then select the file to restore. When Restore is completed Reboot to take effect.")
         runScript('script.xbmcbackup')
    else:
        try:
            response=urllib2.urlopen('http://www.google.com',timeout=10)
            inetconnected =True
        except urllib2.URLError:
            inetconnected = False
 
        if inetconnected:
            addon_log('Internet Connected')
            DeletePackages()
        else:
            addon_log('No Internet Access')
            dialog.ok("CosmiTV", "You are not connected to Internet!", "Please plug the device to your internet router", "or check the Set Up instructions to connect to your WiFi")

            
def autorun():
    checkinet()
            
            
autorun()

